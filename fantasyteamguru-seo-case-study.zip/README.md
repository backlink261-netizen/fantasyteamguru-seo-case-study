FantasyTeamGuru – IPL Data Intelligence Platform
https://www.fantasyteamguru.com

This repository is an SEO case study showcasing clean URLs,
structured data, and IPL analytics pages.

Pages Covered:
- MI vs RCB Head-to-Head (Match 34)
- IPL 2025 Orange Cap
- IPL 2025 Season Topper
- Player Profile: Ravindra Jadeja
